// Main aggregation file for Office Scripts types
// This file brings together all modular type definitions

// Core exports
export * from './core/workbook';
export * from './core/worksheet';  
export * from './core/range';
export * from './core/application';

// Feature exports
export * from './tables/table';
export * from './charts/chart';
export * from './pivot-tables/pivot-table';
export * from './shapes/shape';

// Support exports
export * from './formatting/range-format';
export * from './comments/comment';
export * from './protection/worksheet-protection';

// Utils and globals
export * from './utils/global';

// Global namespace declaration that merges all modules
declare global {
  namespace ExcelScript {
    // All interfaces are available through the exports above
    // TypeScript's declaration merging handles the rest
  }
}

// Global main function declaration
declare function main(workbook: ExcelScript.Workbook): void | Promise<void>;
