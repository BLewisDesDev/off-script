# Office Scripts Modular Type Definitions

This package provides comprehensive TypeScript definitions for Office Scripts development, organized in a modular structure for better maintainability and developer experience.

## Structure

- `core/` - Fundamental Excel objects (Workbook, Worksheet, Range, Application)
- `tables/` - Excel Tables functionality  
- `charts/` - Chart creation and manipulation
- `pivot-tables/` - PivotTable operations
- `shapes/` - Shape, Image, Line, and drawing objects
- `formatting/` - All formatting interfaces (Range, Conditional, Number)
- `data-validation/` - Input validation and rules
- `filtering-sorting/` - Data filtering and sorting operations
- `comments/` - Comment and collaboration features
- `protection/` - Worksheet and workbook protection
- `slicers/` - Slicer interfaces
- `page-layout/` - Page setup and printing
- `metadata/` - Properties, named items, styles
- `external/` - External data connections
- `styles/` - Style definitions
- `utils/` - Support types and global declarations

## Usage

```typescript
import { Workbook, Worksheet, Range } from './office-scripts-types';

function main(workbook: Workbook) {
  const sheet = workbook.getActiveWorksheet();
  const range = sheet.getRange("A1:C10");
  // Full type safety and IntelliSense support
}
```

## Development

- `npm run validate` - Type check all modules
- `npm run build` - Compile type definitions
- `npm run clean` - Remove build artifacts
