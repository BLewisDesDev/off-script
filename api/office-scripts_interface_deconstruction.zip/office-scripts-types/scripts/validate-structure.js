#!/usr/bin/env node

// Validation script to ensure all modules follow conventions
const fs = require('fs');
const path = require('path');

const REQUIRED_DIRS = [
  'core', 'tables', 'charts', 'pivot-tables', 'shapes', 
  'formatting', 'data-validation', 'filtering-sorting', 
  'comments', 'protection', 'slicers', 'page-layout',
  'metadata', 'external', 'styles', 'utils'
];

console.log('🔍 Validating Office Scripts type structure...');

let isValid = true;

// Check all required directories exist
REQUIRED_DIRS.forEach(dir => {
  const dirPath = path.join(__dirname, '..', dir);
  if (!fs.existsSync(dirPath)) {
    console.error(`❌ Missing required directory: ${dir}`);
    isValid = false;
  } else {
    console.log(`✅ Found directory: ${dir}`);
  }
});

// Check index.d.ts exists
const indexPath = path.join(__dirname, '..', 'index.d.ts');
if (!fs.existsSync(indexPath)) {
  console.error('❌ Missing index.d.ts file');
  isValid = false;
} else {
  console.log('✅ Found index.d.ts');
}

if (isValid) {
  console.log('\n🎉 Structure validation passed!');
  process.exit(0);
} else {
  console.log('\n💥 Structure validation failed!');
  process.exit(1);
}
