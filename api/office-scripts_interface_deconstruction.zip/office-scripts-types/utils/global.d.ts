// Global function type that must be present in every Office Script
declare type MainFunction = (workbook: ExcelScript.Workbook) => void | Promise<void>;

// Export for module usage
export { MainFunction };
