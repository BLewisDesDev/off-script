// Core Workbook interface
// This is an example of how to structure each module

declare namespace ExcelScript {
  interface Workbook {
    // Worksheet management
    getWorksheets(): Worksheet[];
    getWorksheet(name: string): Worksheet | undefined;
    addWorksheet(name?: string): Worksheet;
    getActiveWorksheet(): Worksheet;
    getFirstWorksheet(visibleOnly?: boolean): Worksheet;
    getLastWorksheet(visibleOnly?: boolean): Worksheet;

    // Cell and range access
    getActiveCell(): Range;
    getSelectedRange(): Range;
    getSelectedRanges(): RangeAreas;

    // Data objects
    getTables(): Table[];
    getTable(name: string): Table | undefined;
    getPivotTables(): PivotTable[];
    getPivotTable(name: string): PivotTable | undefined;
    getCharts(): Chart[];
    getChart(name: string): Chart | undefined;

    // Properties
    getProperties(): WorkbookProperties;
    getName(): string;
    getAutoSave(): boolean;
    getIsDirty(): boolean;
    getReadOnly(): boolean;

    // Application access
    getApplication(): Application;
    getProtection(): WorkbookProtection;

    // Operations
    save(): void;
  }
}

export { Workbook };
